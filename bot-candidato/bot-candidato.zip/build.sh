#!/bin/bash

zip -r "bot-candidato.zip" * -x "bot-candidato.zip"